import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, GoogleCloudOptions
from apache_beam.io.gcp.bigquery import WriteToBigQuery, BigQueryDisposition
from google.cloud import bigquery
import json

class CleanMetadata(beam.DoFn):
    """
    A DoFn class to clean metadata by removing unwanted characters.
    """
    def process(self, element):
        """
        Process each element (row) of the metadata.
        
        Args:
            element (dict): A dictionary representing a row of metadata.
        
        Yields:
            dict: The cleaned metadata row with newline and carriage return characters removed.
        """
        # Remove newline and carriage return characters from string values
        cleaned_element = {k: v.replace('\n', '').replace('\r', '') if isinstance(v, str) else v 
                           for k, v in element.items()}
        yield cleaned_element

def run(argv=None):
    """
    Builds and runs the Apache Beam pipeline.
    
    Args:
        argv (list): Command line arguments (optional).
    """
    # Set up pipeline options
    options = PipelineOptions(argv)
    google_cloud_options = options.view_as(GoogleCloudOptions)
    google_cloud_options.project = 'damg7245-assignment1-436117'  # Your GCP project ID
    google_cloud_options.region = 'us-east1'  # Your GCP region
    google_cloud_options.temp_location = 'gs://gaia-benchmark-dataset/temp'  # GCS bucket for temporary files
    google_cloud_options.staging_location = 'gs://gaia-benchmark-dataset/staging'  # GCS bucket for staging files

    # Create and run the pipeline
    with beam.Pipeline(options=options) as pipeline:
        # Read the JSONL file from GCS and process it
        metadata = (
            pipeline
            | 'ReadMetadata' >> beam.io.ReadFromText('gs://gaia-benchmark-dataset/GAIA/2023/validation/metadata.jsonl')
            | 'ParseJSON' >> beam.Map(lambda x: json.loads(x))  # Parse each line as JSON
            | 'CleanMetadata' >> beam.ParDo(CleanMetadata())  # Apply the cleaning function
        )

        # Define the BigQuery table schema
        schema = {
            'fields': [
                {'name': 'Annotator Metadata', 'type': 'RECORD', 'mode': 'NULLABLE', 'fields': [
                    {'name': 'Number of tools', 'type': 'INTEGER', 'mode': 'NULLABLE'},
                    {'name': 'Tools', 'type': 'STRING', 'mode': 'NULLABLE'},
                    {'name': 'How long did this take', 'type': 'STRING', 'mode': 'NULLABLE'},
                    {'name': 'Number of steps', 'type': 'STRING', 'mode': 'NULLABLE'},
                    {'name': 'Steps', 'type': 'STRING', 'mode': 'NULLABLE'}
                ]},
                {'name': 'Final answer', 'type': 'STRING', 'mode': 'NULLABLE'},
                {'name': 'file_name', 'type': 'STRING', 'mode': 'NULLABLE'},
                {'name': 'Level', 'type': 'INTEGER', 'mode': 'NULLABLE'},
                {'name': 'Question', 'type': 'STRING', 'mode': 'NULLABLE'},
                {'name': 'task_id', 'type': 'STRING', 'mode': 'NULLABLE'}
            ]
        }

        # Write the cleaned data to BigQuery
        metadata | 'WriteToBigQuery' >> WriteToBigQuery(
            table='damg7245-assignment1-436117:validationDataset001.metadataTable',  # Your BigQuery table
            schema=schema,
            create_disposition=BigQueryDisposition.CREATE_IF_NEEDED,  # Create the table if it doesn't exist
            write_disposition=BigQueryDisposition.WRITE_TRUNCATE,  # Overwrite the table if it exists
            custom_gcs_temp_location='gs://gaia-benchmark-dataset/temp'  # GCS bucket for temporary files
        )

if __name__ == '__main__':
    run()