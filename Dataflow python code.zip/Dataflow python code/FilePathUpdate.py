from google.cloud import storage, bigquery

# Set up your Google Cloud project and bucket details
project = 'damg7245-assignment1-436117'
region = 'us-east1'
bucket_name = 'gaia-benchmark-dataset'
folder_path = 'GAIA/2023/validation'
table_id = 'damg7245-assignment1-436117.validationDataset001.metadataTable'

# Initialize the Google Cloud Storage and BigQuery clients
storage_client = storage.Client(project=project)
bigquery_client = bigquery.Client(project=project)

# Function to list files in a GCS bucket folder
def list_gcs_files(bucket_name, folder_path):
    bucket = storage_client.bucket(bucket_name)
    blobs = bucket.list_blobs(prefix=folder_path)
    return [blob.name for blob in blobs if not blob.name.endswith('/')]

# Function to update the gcs_file_path in BigQuery
def update_gcs_file_path(task_id, gcs_file_path):
    update_query = f"""
        UPDATE `{table_id}`
        SET gcs_file_path = @gcs_file_path
        WHERE task_id = @task_id
    """
    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter("gcs_file_path", "STRING", gcs_file_path),
            bigquery.ScalarQueryParameter("task_id", "STRING", task_id),
        ]
    )
    bigquery_client.query(update_query, job_config=job_config)
    print(f"Updated task_id {task_id} with gcs_file_path {gcs_file_path}.")

# List files in the specified folder in the GCS bucket
gcs_files = list_gcs_files(bucket_name, folder_path)

# Extract task_id from file names and update BigQuery table
for gcs_file in gcs_files:
    file_name = gcs_file.split('/')[-1]
    task_id = file_name.rsplit('.', 1)[0]  # Remove file extension to get task_id
    gcs_file_path = f"@https://storage.cloud.google.com/{bucket_name}/{gcs_file}"
    try:
        update_gcs_file_path(task_id, gcs_file_path)
    except Exception as e:
        print(f"Failed to update task_id {task_id}: {e}")

print("GCS file path update completed.")