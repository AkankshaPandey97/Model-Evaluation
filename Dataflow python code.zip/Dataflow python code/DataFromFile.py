import io
import logging
import openpyxl
import fitz  # PyMuPDF
from PIL import Image
import pytesseract
import csv
from pydub import AudioSegment
import speech_recognition as sr
from google.cloud import storage, bigquery, vision
import os
import tempfile
import librosa
import soundfile as sf
import zipfile
import json
from pptx import Presentation
import xml.etree.ElementTree as ET

# Set up logging
logging.basicConfig(level=logging.INFO)

# Set up your Google Cloud project and bucket details
project = 'damg7245-assignment1-436117'
bucket_name = 'gaia-benchmark-dataset'
table_id = 'damg7245-assignment1-436117.validationDataset001.metadataTable'

# Initialize the Google Cloud Storage and BigQuery clients
storage_client = storage.Client(project=project)
bigquery_client = bigquery.Client(project=project)

def read_gcs_file(bucket_name, file_path):
    """
    Read a file from Google Cloud Storage.
    
    Args:
    bucket_name (str): Name of the GCS bucket
    file_path (str): Path to the file within the bucket
    
    Returns:
    bytes: Content of the file, or None if an error occurs
    """
    try:
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(file_path)
        if not blob.exists():
            logging.warning(f"File does not exist: {file_path}")
            return None
        return blob.download_as_bytes()
    except Exception as e:
        logging.error(f"Error reading file from GCS: {file_path}. Error: {str(e)}")
        return None

def extract_text_from_file(file_path, file_content):
    """
    Extract text from various file types.
    
    Args:
    file_path (str): Path to the file
    file_content (bytes): Content of the file
    
    Returns:
    str: Extracted text from the file
    """
    if file_content is None:
        logging.warning(f"No content for file: {file_path}")
        return ""
    
    file_extension = os.path.splitext(file_path)[1].lower()
    
    try:
        # Call appropriate function based on file extension
        if file_extension in ['.xlsx', '.xls']:
            return extract_text_from_excel(file_content)
        elif file_extension == '.pdf':
            return extract_text_from_pdf(file_content)
        elif file_extension in ['.png', '.jpg', '.jpeg']:
            return extract_text_from_image(file_content)
        elif file_extension in ['.mp3', '.wav', '.ogg']:
            return transcribe_audio(file_content, file_extension[1:])
        elif file_extension == '.txt':
            return file_content.decode('utf-8', errors='ignore')
        elif file_extension == '.csv':
            return extract_text_from_csv(file_content)
        elif file_extension == '.zip':
            return extract_text_from_zip(file_content)
        elif file_extension == '.pdb':
            return extract_text_from_pdb(file_content)
        elif file_extension == '.jsonld':
            return extract_text_from_jsonld(file_content)
        elif file_extension == '.pptx':
            return extract_text_from_pptx(file_content)
        elif file_extension == '.xml':
            return extract_text_from_xml(file_content)
        else:
            logging.warning(f"Unsupported file type: {file_extension}")
            return ""
    except Exception as e:
        logging.error(f"Error extracting text from {file_path}: {str(e)}")
        return ""

def extract_text_from_excel(file_content):
    """Extract text from Excel files."""
    try:
        workbook = openpyxl.load_workbook(io.BytesIO(file_content), data_only=True)
        text = []
        for sheet in workbook.sheetnames:
            worksheet = workbook[sheet]
            for row in worksheet.iter_rows(values_only=True):
                text.append(" ".join(str(cell) for cell in row if cell is not None))
        return "\n".join(text)
    except Exception as e:
        logging.error(f"Error extracting text from Excel: {str(e)}")
        return ""

def extract_text_from_pdf(file_content):
    """Extract text from PDF files."""
    try:
        pdf_document = fitz.open(stream=file_content, filetype="pdf")
        text = []
        for page in pdf_document:
            text.append(page.get_text())
        return "\n".join(text)
    except Exception as e:
        logging.error(f"Error extracting text from PDF: {str(e)}")
        return ""

def extract_text_from_image(file_content):
    """Extract text from image files using Google Cloud Vision API."""
    try:
        client = vision.ImageAnnotatorClient()
        image = vision.Image(content=file_content)
        response = client.text_detection(image=image)
        texts = response.text_annotations
        
        if texts:
            return texts[0].description
        else:
            return ""
    except Exception as e:
        logging.error(f"Error extracting text from image: {str(e)}")
        return ""

def transcribe_audio(file_content, file_extension):
    """Transcribe audio files to text."""
    try:
        # Load the audio file using librosa
        audio_data, sample_rate = librosa.load(io.BytesIO(file_content), sr=None)
        
        # Save as a temporary WAV file
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as temp_wav:
            sf.write(temp_wav.name, audio_data, sample_rate)
            wav_path = temp_wav.name

        recognizer = sr.Recognizer()
        with sr.AudioFile(wav_path) as source:
            audio_data = recognizer.record(source)
            text = recognizer.recognize_google(audio_data)

        # Ensure the temporary file is removed
        try:
            os.remove(wav_path)
        except FileNotFoundError:
            logging.warning(f"Temporary file {wav_path} not found for deletion")

        return text
    except FileNotFoundError as e:
        logging.error(f"Error accessing temporary audio file: {str(e)}")
        return ""
    except Exception as e:
        logging.error(f"Error transcribing audio: {str(e)}")
        return ""

def extract_text_from_csv(file_content):
    """Extract text from CSV files."""
    try:
        csv_content = file_content.decode('utf-8', errors='ignore').splitlines()
        csv_reader = csv.reader(csv_content)
        text = []
        for row in csv_reader:
            text.append(" ".join(row))
        return "\n".join(text)
    except Exception as e:
        logging.error(f"Error extracting text from CSV: {str(e)}")
        return ""

def extract_text_from_zip(file_content):
    """Extract text from ZIP files by processing each contained file."""
    try:
        with zipfile.ZipFile(io.BytesIO(file_content)) as zip_file:
            text = []
            for file_name in zip_file.namelist():
                with zip_file.open(file_name) as file:
                    content = file.read()
                    text.append(extract_text_from_file(file_name, content))
        return "\n".join(text)
    except Exception as e:
        logging.error(f"Error extracting text from ZIP: {str(e)}")
        return ""

def extract_text_from_pdb(file_content):
    """Extract text from PDB files (assuming they are text-based)."""
    try:
        return file_content.decode('utf-8', errors='ignore')
    except Exception as e:
        logging.error(f"Error extracting text from PDB: {str(e)}")
        return ""

def extract_text_from_jsonld(file_content):
    """Extract text from JSONLD files."""
    try:
        json_data = json.loads(file_content)
        def extract_text(obj):
            if isinstance(obj, str):
                return obj
            elif isinstance(obj, dict):
                return ' '.join(extract_text(v) for v in obj.values())
            elif isinstance(obj, list):
                return ' '.join(extract_text(item) for item in obj)
            else:
                return ''
        return extract_text(json_data)
    except Exception as e:
        logging.error(f"Error extracting text from JSONLD: {str(e)}")
        return ""

def extract_text_from_xml(file_content):
    """Extract text from XML files."""
    try:
        root = ET.fromstring(file_content)
        text = []
        for elem in root.iter():
            if elem.text:
                text.append(elem.text.strip())
        return "\n".join(text)
    except Exception as e:
        logging.error(f"Error extracting text from XML: {str(e)}")
        return ""

def extract_text_from_pptx(file_content):
    """Extract text from PowerPoint (PPTX) files."""
    try:
        prs = Presentation(io.BytesIO(file_content))
        text = []
        for slide in prs.slides:
            for shape in slide.shapes:
                if hasattr(shape, 'text'):
                    text.append(shape.text)
        return "\n".join(text)
    except Exception as e:
        logging.error(f"Error extracting text from PPTX: {str(e)}")
        return ""

def update_bigquery(task_id, extracted_text):
    """
    Update the BigQuery table with extracted text for a given task_id.
    
    Args:
    task_id (str): The task ID to update
    extracted_text (str): The extracted text to be inserted
    """
    try:
        if not extracted_text:
            logging.warning(f"No text to update for task_id {task_id}")
            return

        update_query = f"""
            UPDATE `{table_id}`
            SET extractedData = @extracted_text
            WHERE task_id = @task_id
        """
        job_config = bigquery.QueryJobConfig(
            query_parameters=[
                bigquery.ScalarQueryParameter("extracted_text", "STRING", extracted_text),
                bigquery.ScalarQueryParameter("task_id", "STRING", task_id),
            ]
        )
        query_job = bigquery_client.query(update_query, job_config=job_config)
        query_job.result()  # Wait for the query to finish
        logging.info(f"Updated task_id {task_id} with extracted data.")
    except Exception as e:
        logging.error(f"Failed to update BigQuery for task_id {task_id}: {str(e)}")

# Main execution
if __name__ == "__main__":
    # Query to get task_ids from BigQuery table
    query = f"""
        SELECT task_id, gcs_file_path
        FROM `{table_id}`
        WHERE task_id IS NOT NULL
    """
    query_job = bigquery_client.query(query)
    rows = query_job.result()

    # Initialize counters and lists for tracking
    missing_files = []
    invalid_paths = []
    processed_files = 0
    total_files = 0

    # Main processing loop
    for row in rows:
        total_files += 1
        task_id = row.task_id
        file_path = row.gcs_file_path
        try:
            # Validate file path
            if file_path is None:
                logging.warning(f"Invalid file path for task_id {task_id}: None")
                invalid_paths.append(task_id)
                continue

            if not file_path.startswith('gs://'):
                logging.warning(f"Invalid GCS file path format for task_id {task_id}: {file_path}")
                invalid_paths.append(task_id)
                continue

            # Extract GCS path and read file content
            gcs_path = file_path.replace('gs://gaia-benchmark-dataset/', '')
            file_content = read_gcs_file(bucket_name, gcs_path)
            if file_content is None:
                logging.warning(f"File not found in GCS for task_id {task_id}: {gcs_path}")
                missing_files.append(task_id)
                continue
            
            # Extract text from file
            extracted_text = extract_text_from_file(file_path, file_content)
            
            if not extracted_text:
                logging.warning(f"No text extracted for task_id {task_id}")
                continue

            # Truncate extracted_text if it's too long
            max_length = 1048576  # BigQuery's maximum string length
            if len(extracted_text) > max_length:
                extracted_text = extracted_text[:max_length]
                logging.warning(f"Truncated extracted text for task_id {task_id}")

            # Update BigQuery with extracted text
            update_bigquery(task_id, extracted_text)
            processed_files += 1
            if processed_files % 100 == 0:
                logging.info(f"Processed {processed_files} files out of {total_files}")

        except Exception as e:
            logging.error(f"Failed to process task_id {task_id}: {str(e)}")

    # Log summary information
    logging.info(f"Total files processed: {processed_files}")
    logging.info(f"Total files: {total_files}")

    if invalid_paths:
        logging.warning("The following task_ids have invalid file paths:")
        for task_id in invalid_paths:
            logging.warning(task_id)

    if missing_files:
        logging.warning("The following task_ids do not have corresponding files in the bucket:")
        for task_id in missing_files:
            logging.warning(task_id)

    logging.info("Data extraction and update completed.")